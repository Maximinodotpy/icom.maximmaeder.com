package ch.fhnw.prog1.exercise.textanalysis;

public class WordCounter {

    public void add(String word) {
        // TODO: add `word` to your data structure
    }

    public String topWord() {
        // TODO: return the word most frequently occurring in your data structure
        return "";
    }
}
