package ch.fhnw.prog1.exercise.smarthome;

/**
 * Die Hauptklasse im SmartHome-System. Enthält eine Sammlung
 * von Räumen (Klasse {@link Room}) und eine Reihe von Methoden,
 * welche die SmartHome-Funktionalität implementieren.
 */
public class Home {
    private final Room[] rooms;

    public Home(Room[] rooms) {
        this.rooms = rooms;
    }

    public Room[] getRooms() {
        return rooms;
    }

    /**
     * Schaltet alle Lampen in allen Räumen aus.
     */
    public void turnAllOff() {
        // TODO
    }

    /**
     * Wählt einen zufälligen Raum im Haus und schaltet alle
     * Lampen in diesem Raum ein und die restlichen im Haus
     * aus. Die Helligkeit der eingeschalteten Lampen wird
     * auf einen zufälligen Wert zwischen 0.5 und 1.0 gesetzt.
     */
    public void randomize() {
        // TODO
    }

    /**
     * Findet den ersten Raum im Haus, in dem nicht alle Lampen
     * eingeschaltet und auf voller Helligkeit sind. In diesem
     * Raum werden alle Lampen eingeschaltet und auf volle
     * Helligkeit (1.0) gesetzt. Sind bereits in allen Räumen
     * alle Lampen eingeschaltet und auf voller Helligkeit,
     * passiert nichts.
     */
    public void turnNextRoomBright() {
        // TODO
    }

    /**
     * Findet in jedem Raum die Lampe mit dem jeweils kleinsten
     * Stromverbrauch. Diese Lampen werden eingeschaltet und auf
     * eine Helligkeit von 0.8 gesetzt; alle anderen Lampen werden
     * ausgeschaltet.
     */
    public void saveEnergy() {
        // TODO
    }

    /**
     * Findet den Raum im Haus, der den Namen "Hallway" hat und
     * gibt ihn zurück. Es wird davon ausgegangen, dass immer
     * genau eine Hallway existiert.
     */
    public Room findHallway() {
        // TODO
        return null;
    }

    /**
     * Findet alle Räume im Haus, welche irgendwo im Namen den
     * String "Bedroom" enthalten, und gibt diese in einem Array
     * zurück. Das Array darf auch grösser als nötig sein und
     * null-Einträge enthalten. Es darf aber maximal so gross
     * sein wie die Gesamtanzahl der Räume im Haus.
     */
    public Room[] findBedrooms() {
        // TODO
        return null;
    }

    /**
     * Schaltet den "Nachtmodus" ein, welcher in allen Bedrooms
     * und in der Hallway je eine (beliebige) Lampe einschaltet
     * und die Helligkeit auf 0.3 setzt. Alle anderen Lampen
     * werden ausgeschaltet.
     * <p>
     * Verwendet die Methoden findHallway und findBedrooms.
     */
    public void nightMode() {
        // TODO
    }
}
